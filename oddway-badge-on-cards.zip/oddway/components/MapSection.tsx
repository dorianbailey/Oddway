import { RouteMap } from "./RouteMap";
import { formatCoordinates, formatDetour } from "@/lib/format";
import type { Route, Stop } from "@/types/oddway";

interface MapSectionProps {
  stops: Stop[];
  /** The drawn route. Null until the routing API exists. */
  route?: Route | null;
}

/**
 * The map band.
 *
 * This is a server component: it renders the heading, the copy and a text
 * fallback, and delegates the interactive canvas to <RouteMap />, which is the
 * only client component involved. The stop list below the map is not a
 * decoration — a WebGL canvas is unreadable to assistive technology, so the
 * list is the accessible equivalent and stays in the DOM either way.
 */
export function MapSection({ stops, route = null }: MapSectionProps) {
  return (
    <section
      id="map"
      data-surface="dark"
      aria-labelledby="map-heading"
      className="bg-pine-deep text-paper"
    >
      <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8 sm:py-20">
        <h2 id="map-heading" className="max-w-[20ch] text-section">
          See the whole route and everything odd beside it
        </h2>
        <p className="mt-5 max-w-[62ch] text-lede text-lichen">
          OddWay draws your route first, then plots every stop that falls inside
          the detour you&rsquo;re willing to make. No hunting through a list to
          work out what is actually on the way.
        </p>

        <div className="relative mt-10 aspect-4/3 overflow-hidden rounded-[4px] border border-brass/30 bg-paper-sunk sm:aspect-16/9">
          <RouteMap stops={stops} route={route} />
        </div>

        {route === null ? (
          <p className="mt-5 max-w-[62ch] border-l-2 border-brass pl-4 text-[0.95rem] text-lichen">
            Route drawing isn&rsquo;t switched on yet, so the map is framed on
            the stops themselves. Once the routing engine lands, the line
            appears here and the stops re-sort by detour.
          </p>
        ) : null}

        {/* Text equivalent of the map, and the path when WebGL is unavailable. */}
        <details className="mt-8 rounded-[3px] border border-brass/25 p-5">
          <summary className="cursor-pointer font-display font-bold">
            List these {stops.length} stops as text
          </summary>
          <ul className="mt-5 space-y-4">
            {stops.map((stop, index) => (
              <li key={stop.id} className="border-l-2 border-brass/40 pl-4">
                <p className="font-display font-bold">
                  {index + 1}. {stop.name}
                </p>
                <p className="text-[0.95rem] text-lichen">
                  {stop.city}, {stop.state} — {formatDetour(stop.detourMinutes)}
                </p>
                <p className="font-display text-[0.85rem] text-lichen/80 italic">
                  {formatCoordinates(stop.latitude, stop.longitude)}
                </p>
              </li>
            ))}
          </ul>
        </details>
      </div>
    </section>
  );
}
